var inicio=function (){
	$(".cantidad").keyup(function(e){
		if($(this).val()!=''){
			if(e.keyCode==13){
				var id=$($this).attr('data-id');
				var precio=$($this).attr('data-precio');
				var cantidad=$(this).val();
				$(this).parentsUntil('.producto').find('.subtotal').text('Subtotal:'+(precio*cantidad));
				$.post('../js/modificar.php',{
					Id:id,
					Precio:precio
					Cantidad:cantidad
				},function(e){

				});
			}
		}
	});
}
$(document).on('ready',inicio);