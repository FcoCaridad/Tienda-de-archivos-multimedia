/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author david
 */
public class Persona {
    protected String nombre;
    protected String dui;
    protected String direccion;
    protected int edad;
    protected String correo;
    protected String telefono;
    protected String genero;

    public Persona() {
    }

    public Persona(String nombre, String dui, String direccion, int edad, String correo, String telefono, String genero) {
        this.nombre = nombre;
        this.dui = dui;
        this.direccion = direccion;
        this.edad = edad;
        this.correo = correo;
        this.telefono = telefono;
        this.genero = genero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDui() {
        return dui;
    }

    public void setDui(String dui) {
        this.dui = dui;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    @Override
    public String toString() {
        return "\nnombre=" + nombre + "\ndui=" + dui + "\ndireccion=" + direccion + "\nedad=" + edad + "\ncorreo=" + correo + "\nelefono=" + telefono + "\ngenero=" + genero;
    }
    
    
}
