/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author david
 */
public class Proveedor extends Persona{
    private int idProveedor;

    public Proveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }

    public Proveedor(int idProveedor, String nombre, String dui, String direccion, int edad, String correo, String telefono, String genero) {
        super(nombre, dui, direccion, edad, correo, telefono, genero);
        this.idProveedor = idProveedor;
    }

    public int getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }

    @Override
    public String toString() {
        return "Proveedor" + "\nidProveedor=" + idProveedor + "\nnombre=" + nombre + "\ndui=" + dui + "\ndireccion=" + direccion + "\nedad=" + edad + "\ncorreo=" + correo + "\nelefono=" + telefono + "\ngenero=" + genero;
    }
}
