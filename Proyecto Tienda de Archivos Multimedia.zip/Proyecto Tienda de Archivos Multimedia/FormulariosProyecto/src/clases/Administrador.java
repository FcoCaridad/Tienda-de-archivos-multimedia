/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author david
 */
public class Administrador extends Persona {
    private int idAdmin;

    public Administrador(int idAdmin) {
        this.idAdmin = idAdmin;
    }

    public Administrador(int idAdmin, String nombre, String dui, String direccion, int edad, String correo, String telefono, String genero) {
        super(nombre, dui, direccion, edad, correo, telefono, genero);
        this.idAdmin = idAdmin;
    }

    public int getIdAdmin() {
        return idAdmin;
    }

    public void setIdAdmin(int idAdmin) {
        this.idAdmin = idAdmin;
    }
    
    public void agregarProducto(){
        
    }
    public void modificarProducto(){
        
    }
    public void eliminarProducto(){
        
    }
    public void mostrarProducto(){
        
    }
    public void agregarProveedor(){
        
    }
     public void modificarProveedor(){
        
    }
    public void eliminarProveedor(){
        
    }
    public void mostrarProveedor(){
        
    }
    public void mostrarReportesProductosMasVendidos(){
        
    }
     public void agregarClientes(){
        
    }
     public void modificarClientes(){
        
    }
    public void eliminarClientes(){
        
    }
    public void mostrarClientes(){
        
    }
    public void realizarPedidoMultimedia(){
        
    }
     public void agregarCategoria(){
        
    }
     public void modificarCategoria(){
        
    }
    public void eliminarCategoria(){
        
    }
    public void mostrarCategoria(){
        
    }
    public void mostrarReportes(){
        
    }
    
    @Override
    public String toString() {
        return "Administrador " + "idAdmin=" + idAdmin +"\nnombre=" + nombre + "\ndui=" + dui + "\ndireccion=" + direccion + "\nedad=" + edad + "\ncorreo=" + correo + "\nelefono=" + telefono + "\ngenero=" + genero ;
    }

    
}
