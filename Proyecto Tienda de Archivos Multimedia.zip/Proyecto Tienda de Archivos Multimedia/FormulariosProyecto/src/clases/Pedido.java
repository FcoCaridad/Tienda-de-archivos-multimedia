/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author david
 */
public class Pedido {

    private int idPedido;
    private String fechaPedido;
    private String fechaEntrega;
    
     public Pedido() {
    }

    public Pedido(int idPedido, String fechaPedido, String fechaEntrega) {
        this.idPedido = idPedido;
        this.fechaPedido = fechaPedido;
        this.fechaEntrega = fechaEntrega;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public String getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(String fechaPedido) {
        this.fechaPedido = fechaPedido;
    }

    public String getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(String fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    @Override
    public String toString() {
        return "Pedido" + "\nidPedido:" + idPedido + "\nfechaPedido:" + fechaPedido + "\nfechaEntrega:" + fechaEntrega ;
    }
     
     
}
