import java.util.Vector;

public class Reporte {

  private Supervisor idSupervisor;

  private Integer idReporte;

  private String descripcion;

  private String fecha;

    public Vector  1;

  public void Reporte() {
  }

  public void Reporte(Supervisor idSupervisor, Integer idReporte, String descripcion, String fecha) {
  }

  public void setIdSupervisor(Supervisor idSupervisor) {
  }

  public Supervisor getIdSupervisor() {
  return null;
  }

  public void setIdReporte(Integer idReporte) {
  }

  public Integer getIdReporte() {
  return null;
  }

  public void setDescripcion(String descripcion) {
  }

  public String getDescripcion() {
  return null;
  }

  public void setFecha(String fecha) {
  }

  public String getFecha() {
  return null;
  }

}