public class Persona {

  protected String nombre;

  protected String dui;

  protected String direccion;

  protected Integer edad;

  protected String correo;

  protected Integer telefono;

  protected String genero;

  public void Persona() {
  }

  public void Persona(String nombre, String dui, String direccion, Integer edad, String correo, Integer telefono, String genero) {
  }

  public void setNombre(String nombre) {
  }

  public String getNombre() {
  return null;
  }

  public void setDui(String dui) {
  }

  public String getDui() {
  return null;
  }

  public void setEdad(Integer edad) {
  }

  public Integer getEdad() {
  return null;
  }

  public void setDireccion(String direccion) {
  }

  public String getDireccion() {
  return null;
  }

  public void setCorreo(String correo) {
  }

  public String getCorreo() {
  return null;
  }

  public void setTelefono(Integer telefono) {
  }

  public Integer getTelefono() {
  return null;
  }

  public void setGenero(String genero) {
  }

  public String getGenero() {
  return null;
  }

}