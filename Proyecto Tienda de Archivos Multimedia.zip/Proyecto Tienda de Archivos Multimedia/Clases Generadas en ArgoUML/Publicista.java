public class Publicista extends Persona {

  private Integer idPublicista;

  private String usuario;

  private String contrase�a;

    public CatalogoCategorias Actualiza;

  public void Publicista() {
  }

  public void Publicista(Integer idPublicista, String usuario, String contrase�a) {
  }

  public void setIdPublicista(Integer idPublicista) {
  }

  public Integer getIdPublicista() {
  return null;
  }

  public void setUsuario(String usuario) {
  }

  public String getUsuario() {
  return null;
  }

  public void setContrase�a(String contrase�a) {
  }

  public String getContrase�a() {
  return null;
  }

  public void iniciarSesion(String usuario, String contrase�a) {
  }

  public void actualizarPublicidad() {
  }

}