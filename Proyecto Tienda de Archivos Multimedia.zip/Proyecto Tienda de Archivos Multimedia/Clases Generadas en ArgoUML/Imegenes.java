public class Imegenes extends CatalogoCategorias {
}