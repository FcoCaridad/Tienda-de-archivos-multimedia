import java.util.Vector;

public class Supervisor extends Persona {

  private Integer idSupervisor;

    public Vector  1;

  public void Supervisor() {
  }

  public void Supervisor(Integer idSupervisor) {
  }

  public void setIdSupervisor(Integer idSupervisor) {
  }

  public Integer getIdSupervisor() {
  return null;
  }

  public void resolverProblemasConLaAplicacion() {
  }

  public void agregarProductos() {
  }

  public void eliminarProductos() {
  }

  public void modificarProductos() {
  }

  public void mostrarProductos() {
  }

  public void agregarReporte() {
  }

  public void modificarReporte() {
  }

  public void eliminarReporte() {
  }

  public void mostrarReporte() {
  }

  public void buscarCliente() {
  }

  public void mostrarReporteCategoria() {
  }

  public void iniciarSesion() {
  }

}