public class Cliente Registrado extends Cliente {

  public void seleccionProductos() {
  }

  public void realizarCompra() {
  }

  public void revisaCatalogo() {
  }

}