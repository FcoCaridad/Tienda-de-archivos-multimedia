import java.util.Vector;

public class Factura {

  private Integer idFactura;

  private String descripcion;

  private Double descuento;

  private Double precioUnitario;

  private String fechaEntrega;

  private Double total;

    public Vector  myDetalleFactura;
    public DetalleFactura crea;

  public void Factura() {
  }

  public void Factura(Integer idFactura, String descripcion, Double descuento, Double precioUnitario, String fechaEntrega, Double total) {
  }

  public void setIFactura(Integer idFactura) {
  }

  public Integer getIdFactura() {
  return null;
  }

  public void setDescripcion(String descripcion) {
  }

  public String getDescripcion() {
  return null;
  }

  public void setDescuento(Double descuento) {
  }

  public Double getDescuento() {
  return null;
  }

  public void setPrecioUnitario(Double precioUnitario) {
  }

  public Double getPrecioUnitario() {
  return null;
  }

  public void setFechaEntrega(String fechaEntrega) {
  }

  public String getFechaEntrega() {
  return null;
  }

  public void setTotal(Double total) {
  }

  public Double getTotal() {
  return null;
  }

}