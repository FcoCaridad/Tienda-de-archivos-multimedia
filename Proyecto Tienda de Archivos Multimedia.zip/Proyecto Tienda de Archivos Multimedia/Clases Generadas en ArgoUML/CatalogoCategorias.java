import java.util.Vector;

public class CatalogoCategorias {

  private Integer idCatalogo;

  private String nombreCategoria;

  private String descripcionCategoria;

    /**
   * 
   * @element-type Producto
   */
  public Vector  Tiene;
    public Publicista Actualiza;

  public void CatalogoCategoria() {
  }

  public void CatalogoCategoria(Integer idCatalogo, String nombreCategoria, String descripcionCategoria) {
  }

  public void setIdCatalogo(Integer idCatalogo) {
  }

  public Integer getIdCatalogo() {
  return null;
  }

  public void setNombreCatalogo(String nombreCatalogo) {
  }

  public String getNombreCatalogo() {
  return null;
  }

  public void setDescripcion(String descripcion) {
  }

  public String getDescripcion() {
  return null;
  }

}