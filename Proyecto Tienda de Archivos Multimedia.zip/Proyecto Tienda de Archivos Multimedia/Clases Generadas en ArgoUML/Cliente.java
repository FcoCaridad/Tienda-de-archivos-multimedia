import java.util.Vector;

public class Cliente extends Persona {

  private Integer idCliente;

    public Vector  1..*;
    /**
   * 
   * @element-type Producto
   */
  public Vector  Factura;
    public Vector  myProducto;
    /**
   * 
   * @element-type Producto
   */
  public Vector  Factura;

  public void Cliente() {
  }

  public void Cliente(Integer idCliente) {
  }

  public void setIdCliente(Integer idCliente) {
  }

  public Integer getIdCliente() {
  return null;
  }

  public void iniciarSesio() {
  }

}