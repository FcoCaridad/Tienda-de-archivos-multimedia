public class Cliente Visitante extends Cliente {

  public void revisarCatalogo() {
  }

}