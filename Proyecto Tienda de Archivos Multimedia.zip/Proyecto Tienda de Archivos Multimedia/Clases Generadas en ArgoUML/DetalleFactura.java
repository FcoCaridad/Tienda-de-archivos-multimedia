public class DetalleFactura {

  private Integer idDetalleFactura;

  private String descripcion;

      public Factura crea;

  public void DetalleFactura() {
  }

  public void DetalleFactura(Integer idDetalleFactura, String descripcion) {
  }

  public void setIdDetalleFactura(Integer idDetalleFactura) {
  }

  public Integer getIdDetalleFactura() {
  return null;
  }

  public void setDescripcion(String descripcion) {
  }

  public String getDescripcion() {
  return null;
  }

}