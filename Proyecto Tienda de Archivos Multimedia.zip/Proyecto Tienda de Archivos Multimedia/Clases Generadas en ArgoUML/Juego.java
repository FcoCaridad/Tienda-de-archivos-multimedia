public class Juego extends CatalogoCategorias {
}