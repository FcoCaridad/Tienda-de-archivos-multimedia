public class Video extends CatalogoCategorias {
}