import java.util.Vector;

public class Pedido {

  private Integer idPedido;

  private String fechaPedido;

  private String fechaEntrega;

    public Administrador Gestiona;
    public Vector  1..*;

  public void Pedido() {
  }

  public void Pedido(Integer idPedido, String fechaPedido, String fechaEntrega) {
  }

  public void setIdPedido(Integer idPedido) {
  }

  public Integer getIdPedido() {
  return null;
  }

  public void setFechaPedido(String fechaPedido) {
  }

  public String getFechaPedido() {
  return null;
  }

  public void setFechaEntrega(String fechaEntrega) {
  }

  public String getFechaEntrega() {
  return null;
  }

}