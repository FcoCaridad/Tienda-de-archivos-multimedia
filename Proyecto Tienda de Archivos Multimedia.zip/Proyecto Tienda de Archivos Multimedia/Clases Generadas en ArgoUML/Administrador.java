import java.util.Vector;

public class Administrador extends Persona {

  private Integer idAdministrador;

    /**
   * 
   * @element-type Pedido
   */
  public Vector  Gestiona;

  public void Administrador() {
  }

  public void Administrador(Integer idAdministrador) {
  }

  public void setIdAdministrador(Integer idAdministrador) {
  }

  public Integer getIdAdministrador() {
  return null;
  }

  public void iniciarSesion() {
  }

  public void agregarProducto() {
  }

  public void modificarProducto() {
  }

  public void eliminarProducto() {
  }

  public void mostrarProducto() {
  }

  public void agregarProveedor() {
  }

  public void modifcarProveedor() {
  }

  public void eliminarProveedor() {
  }

  public void mostrarProveedor() {
  }

  public void mostrarReporteProductosMasVendidos() {
  }

  public void agregarClientes() {
  }

  public void modificarClientes() {
  }

  public void eliminarClientes() {
  }

  public void mostrarClientes() {
  }

  public void realizarPedidosMultimedia() {
  }

  public void agregarCategoria() {
  }

  public void modificarCategoria() {
  }

  public void eliminarCategoria() {
  }

  public void mostrarCategoria() {
  }

  public void mostrarReporteComprasPorCategoria() {
  }

}