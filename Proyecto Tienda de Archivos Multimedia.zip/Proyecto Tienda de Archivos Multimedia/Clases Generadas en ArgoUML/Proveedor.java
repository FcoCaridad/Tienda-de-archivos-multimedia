import java.util.Vector;

public class Proveedor extends Persona {

  private Integer idProveedor;

    /**
   * 
   * @element-type Producto
   */
  public Vector  Suministra;

  public void Proveedor() {
  }

  public void Proveedor(Integer idProveedor) {
  }

  public void setIdProveedor(Integer idProveedor) {
  }

  public Integer getIdProveedor() {
  return null;
  }

  public void iniciarSesion() {
  }

  public void entregarPedidos() {
  }

}