public class Login {

  private Integer idUsuario;

  private String usuario;

  private String contrase�a;

  public void Login() {
  }

  public void Login(Integer idUsuario, String usuario, String contrase�a) {
  }

  public void setIdUsuario(Integer idUsuario) {
  }

  public Integer getIdUsuario() {
  return null;
  }

  public void setUsuario(String usuario) {
  }

  public String getUsuario() {
  return null;
  }

  public void setContrase�a(String contrase�a) {
  }

  public String getContrase�a() {
  return null;
  }

}