import java.util.Vector;

public class Producto {

  private Integer idProducto;

  private Proveedor idProveedor;

  private String nombreProducto;

  private Integer cantidad;

  private Double precio;

  private String descripcion;

    public Proveedor Suministra;
    public CatalogoCategorias Tiene;
    public Vector  1;
    public Cliente Compra;
    public Cliente Factura;
    public Vector  myCliente;
    public Cliente Factura;

  public void Producto() {
  }

  public void Producto(Integer idProducto, Proveedor idProveedor, String idNombreProducto, Integer cantidad, Double precio, String descripcion) {
  }

  public void setIdProducto(Integer idProducto) {
  }

  public Integer getIdProducto() {
  return null;
  }

  public void setIdProveedor(Integer idProveedor) {
  }

  public Integer getIdProveedor() {
  return null;
  }

  public void setNombreProducto(String nombreProducto) {
  }

  public String getNombreProducto() {
  return null;
  }

  public void setCantidad(Integer cantidad) {
  }

  public Integer getCantidad() {
  return null;
  }

  public void setPrecio(Double precio) {
  }

  public Double getPrecio() {
  return null;
  }

  public void setDescripcion(String descripcion) {
  }

  public String getDescripcion() {
  return null;
  }

}