public class Musica extends CatalogoCategorias {
}