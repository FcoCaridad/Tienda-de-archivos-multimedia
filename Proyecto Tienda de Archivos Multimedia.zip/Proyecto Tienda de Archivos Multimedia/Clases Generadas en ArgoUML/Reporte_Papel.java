public class Reporte_Papel extends Reporte {
}